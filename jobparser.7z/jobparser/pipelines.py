# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError as dke
import re


class JobparserPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongobase = client.vacancies


    def process_item(self, item, spider):
        if spider.name == 'hhru':
            item['min_salary'], item['max_salary'], item['currency'] = self.process_salary_hh(item['salary'])
            del item['salary']
        if spider.name == 'sjru':
            item['min_salary'], item['max_salary'], item['currency'] = self.process_salary_sj(item['salary'])
            del item['salary']
        item['_id'] = re.search(r'\d+', item['url'])[0]
        collection = self.mongobase[spider.name]
        try:
            collection.insert_one(item)
        except dke:
            pass
        return item

    def process_salary_hh(self, salary):

        if len(salary) == 1:
            min_salary = None
            max_salary = None
            currency = None
        elif len(salary) == 7:
            min_salary = int(salary[1].replace('\xa0', ''))
            max_salary = int(salary[3].replace('\xa0', ''))
            currency = salary[5]
        elif salary[0] == 'до ':
            max_salary = int(salary[1].replace('\xa0', ''))
            currency = salary[3]
            min_salary = None
        else:
            min_salary = int(salary[1].replace('\xa0', ''))
            currency = salary[3]
            max_salary = None


        return min_salary,max_salary,currency

    def process_salary_sj(self, salary):

        if len(salary) == 1:
            min_salary = None
            max_salary = None
            currency = None
        elif len(salary) == 9:
            min_salary = int(salary[0].replace('\xa0', ''))
            max_salary = int(salary[4].replace('\xa0', ''))
            currency = salary[6]
        elif salary[0] == 'до':
            max_salary = int(salary[3].replace('\xa0000\xa0руб.', '000'))
            currency = 'руб'
            min_salary = None
        else:
            min_salary = int(salary[1].replace('\xa0000\xa0руб.', '000'))
            currency = 'руб'
            max_salary = None


        return min_salary,max_salary,currency